library ieee;
use ieee.std_logic_1164.all;

entity DFF is
	port (d, clk, rst: IN std_logic;
	q: OUT std_logic);
end DFF;

architecture myarch of DFF is
begin
	process (rst, clk)
	begin
		if (rst='1') then
			q<='0';
		elsif (clk'event and clk='1') then
			q<=d;
		end if;
	end process;
end myarch;
