entity latch is
	port (s,r : in bit;
	q,qb : inout bit);
end entity;

architecture myarch of latch is
begin
	q  <= s NAND qb;
	qb <= r NAND q;
end architecture;
