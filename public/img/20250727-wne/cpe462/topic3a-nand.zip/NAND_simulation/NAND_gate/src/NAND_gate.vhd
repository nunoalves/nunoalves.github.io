entity NAND_Gate is 
	port (a, b : in bit;
	x : out bit);
end NAND_gate;

architecture myarch of NAND_gate is
begin			  
	x <= a NAND b;
end myarch;