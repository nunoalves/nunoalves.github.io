entity example is
	port (a,b,clk : in bit;
	q: out bit);
end example;

architecture main of example is	
begin			   
  process (clk)
    begin
    if (clk'event and clk='1') then q<=a NAND b;
    end if;	
  end process;
end example;
