//Billy Ferguson

int n = 30000; // change this variable for more or less trial

boolean appromixate_pi_one_time = true; 

//this function generates a random number between 0 and 1
float randfloat() 
{ 
    return rand()/(float(RAND_MAX)+1);
} 

//this sets up the baudrate of 
void setup()
{
  Serial.begin(9600);
}


       




void loop()
{

    while(appromixate_pi_one_time)
    {
	float m=0;
	float x,y,pi;

	for(int i=0;i<n;i++)
	{
		x = randfloat();
		y = randfloat();

		if(x*x+y*y<=1)
			m++;
		
	}
        
	pi = 4*m/n;
	appromixate_pi_one_time = false; // sets outer loop variable so this will only be computed once

	
	Serial.print("pi is ");
        Serial.println(pi);
    }

}
