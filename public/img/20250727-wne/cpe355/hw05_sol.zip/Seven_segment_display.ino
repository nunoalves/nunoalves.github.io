//Billy Ferguson
//Seven Segment Display


/*The number in the pinout array corresponds to the commented pin number below
  The uncommented pinout value is the pin # on the arduino board and the commented
  value is the pin of the 7 segment display
  For example: 
          pinout[0] = 4
          The commented value below is 2
          This means pin 4 of the arduino needs to be connected to pin 2 of the 7 segment display*/
int pinout[7] = {4,5,6,7,8,9,10};
               //2,3,4,5,8,9,10

               
char pinoutvals[10] = {B0000010, //prints a 0
                        B1001111,//prints a 1
                        B0010001,//prints a 2
                        B0000101,//prints a 3
                        B1001100,//prints a 4
                        B0100100,//prints a 5
                        B0100000,//prints a 6
                        B0001111,//prints a 7
                        B0000000,//prints a 8
                        B0001100};//prints a 9
                        
void my_first_7sd_counter()  
{
  for(int i =0;i<10;i++)
  {
    delay(300);
    for(int j=0;j<7;j++)
      digitalWrite(pinout[j],bitRead(pinoutvals[i],j));
      
  }
}
                        
                        
                        
                        
void setup()
{
  for(int i = 0;i<7;i++)
  {
    pinMode(pinout[i],OUTPUT);//sets each pin in the pinout array as an OUTPUT pin
    digitalWrite(pinout[i],HIGH); //resets all the pins to high turning off all the segments
  }
  Serial.begin(9600);
}

void loop()
{
 my_first_7sd_counter(); //constantly runs the 7 segment display counter(counting from 0-9)
}
    
