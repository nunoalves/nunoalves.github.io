//Billy Ferguson
//Baby Testing

//change the below variable and run the program
// ITS THAT EASY!!!!

int trial_length = 30; //change this variable to change how many "seconds" long your trials are
                       //for parts a and b this value should 30
                       //for part c this value should be

float wallhits = 0.0, outlethits = 0.0;
boolean eletrically_charged_baby,babytrial_problem3 = true;

/*function movedown checks for outlet before moving
then checks that its not at the wall
if its not at the wall it will move down in the y direction
otherwise if either of these checks fail the baby wont move 
and a counter is incremented to denote hitting the wall or outlet

all the other functions move in the same fashion pretty simple to 
understand because of the way I implemented the functions*/
void movedown(short& x,short& y,boolean& ecb)
{
	if(x==11 && y==7) 
        {
	  ecb = true;	
          outlethits++;
        }
	if(y>0)
		y--;
	else 
            wallhits++;
}

void moveup(short& x,short& y,boolean& ecb)
{
	if(x==11 && y==5)
        {
          ecb = true;
          outlethits++;
        }
	if(y<11)
		y++;
	else 
		wallhits++;
}

void moveright(short& x,short& y,boolean& ecb)
{
	if(x==10 && y==6)
        {
            ecb = true;
            outlethits++;
        }
	if(x<11)
		x++;
	else 
		wallhits++;
}

void moveleft(short& x,short& y)
{
	if(x>0)
		x--;
	else 
		wallhits++;
}

float randfloat(int x)
{
  float randfloat = (float)random(x)/x;
}


//set-up 
void setup()
{
  Serial.begin(9600);
}

void loop()
{
	short x,y,move;
        float percent_zapped;

  while(babytrial_problem3)
  {

    for(int j = 0;j<30000;j++)
    {
        
	x=1,y=6;//the baby's original position
        eletrically_charged_baby = false; //resets the break statement giving the baby another chance to 
                                          //win the outlet touching prize!!!!

	for(int i=0;i<trial_length;i++)
	{
		move = random(0,4);
                
		if(move==3)//3 denotes move up
			movedown(x,y,eletrically_charged_baby);
		if(move==2)//2 denotes move right
			moveright(x,y,eletrically_charged_baby);
		if(move==1)//1 denotes move up
			moveup(x,y,eletrically_charged_baby);
		if(move==0)//0 denotes move left
			moveleft(x,y);

                if(eletrically_charged_baby)//ends the trial if baby touches outlet
                   break;
	}	
    }
        percent_zapped = outlethits/300; //becuase outlethits/30000*100 is outlethits/300
        babytrial_problem3 = false;
        // printing the data from the trial
	Serial.print("The probability that Paulo will touch an outlet is ");
	Serial.print(percent_zapped);
        Serial.println("%");
        Serial.print("The average number of times Paulo touches the wall is ");
        Serial.println(wallhits/30000);
  
        
        
  }

}
