//Billy Ferguson
//Homework 8


int NOISEMAKER = 4;
int q[10] = {0,0,0,0,0,0,0,0,0,0};  

volatile int fdi,fdj,fdz;

void fakedelay()
{
  for(int i=0;i<400;i++)
    for(int j=0;j<400;j++)
       fdz=fdi*10;
}

void noise_a()//makes my noise for a
{
 // boolean pancake = true;
   boolean blinkIT=true;
  for(int i = 0;i<10;i++)
  {
    blinkIT = !blinkIT;
    digitalWrite(NOISEMAKER,blinkIT);
    delay(100);
  }
/*  for(int i = 0; i<10;i++)
  {
    digitalWrite(NOISEMAKER,!pancake);
    delay(300);
 }*/
}

void noise_b()//makes my noise for b
{
 // boolean pancake = true;
  
   boolean blinkIT=true;
  for(int i = 0;i<5;i++)
  {
    blinkIT = !blinkIT;
    digitalWrite(NOISEMAKER,blinkIT);
    delay(500);
  }
  
/*  for(int i = 0; i<300;i++)
  {
    digitalWrite(NOISEMAKER,!pancake);
    delay(10);
  }
*/
}

void addA()//adds the value for a to the list
{
  fakedelay();//this is for debouncing purposes
  
  for(int i = 0;i<10;i++)
      if(q[i]==0)
      {
          q[i]=1;//adds an 'A' to the q
          break; 
      }

}  

void addB()//adds the value for a to the list
{
  fakedelay();//this is for debouncing purposes
  
  for(int i = 0;i<10;i++)
      if(q[i]==0)
      {
          q[i]=2;//adds a 'B' to the 'B' to the q
           break;  // get it?
      }
}  

void read_it()//reads the whole array
{
  int temp = 0;
  temp = q[0];
  noInterrupts();//if this is interrupted the whole array can be compromised
  for(int i = 0;i<9;i++)
  {
    q[i] = q[i+1];
  }
  q[9] = 0;
  interrupts();//if this is interrupted the whole array can be compromised
  
  if(temp==1)
      noise_a();//plays noise b if q value is 2
  if(temp==2)
      noise_b();//plays noise b if q value is 2
        
}  

void setup() // sets up all the cool stuff
{
  attachInterrupt(0,addA,CHANGE);
  attachInterrupt(1,addB,CHANGE);
  pinMode(NOISEMAKER,OUTPUT);
  digitalWrite(NOISEMAKER,HIGH);
  Serial.begin(9600);
}

void loop()
{
  delay(500);
  read_it();
  digitalWrite(NOISEMAKER,HIGH);//clears the noisemaker if interrupted and gets left on
}


