double interrupt vDeviceA (void)
{
    !! Take care of I/O Device A
    !! Set Signal X
}
// Setting up network device

void Task1 (void)
{
    while (true)
    {
        !! Wait for Signal X
        !! Handle data to/from I/O Device A
        return;
    }
}
// Sends data

void Task2 (void)
{
    while (true)
    {
        !! Wait for Signal X
        !! Handle data to/from I/O Device A
        return;
    }
}
// Cleans the chaos between lost data, late data, and out of order data

void Task3 (void)
{
    while (true)
    {
        !! Wait for Signal X
        !! Handle data to/from I/O Device A
        return;
    }
}
// Sends status back to user (what type of printer it's attached to)

void main (void)
{
    while(true)
    {
        !! Wait while first stacked item prints
    }
    !! Once first item is printed, move on to next item
}
