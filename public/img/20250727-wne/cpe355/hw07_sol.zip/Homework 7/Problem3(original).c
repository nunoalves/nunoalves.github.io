/*
Reasoning behind this solution:
When designing this pseudo-c code, I had this reasoning - when
reading the contraints, it appeared to me that the four constraints
dealt with two devices, either the Telegraph or the Printer. This
being said, I figured these would be my two devices. I then set
each constraint with a specific task for their given device.
*/

double interrupt vDeviceA (void)
{
    !! Take care of I/O Device A
    !! Set Signal X
}
// Device A is the Printer

double interrupt vDeviceB (void)
{
    !! Take care of I/O Device B
    !! Set Signal Y
}
// Device B is the Telegraph

void Task1 (void)
{
    while (true)
    {
        !! Wait for Signal X
        !! Handle data to/from I/O Device A
        return;
    }
}
// Printer decides which job needs to be printed first

void Task2 (void)
{
    while (true)
    {
        !! Wait for Signal X
        !! Handle data to/from I/O Device A
        return;
    }
}
// Printer provides status to a telegraph that requests it, even if it's printing

void Task3 (void)
{
    while (true)
    {
        !! Wait for Signal Y
        !! Handle data to/from I/O Device B
        return;
    }
}
// Telegraph cleans the data chaos and sends out a clean data stream to the printer

void Task4 (void)
{
    while (true)
    {
        !! Wait for Signal Y
        !! Handle data to/from I/O Device B
        return;
    }
}
// Telegraph figures out what type of printer it is attached to
