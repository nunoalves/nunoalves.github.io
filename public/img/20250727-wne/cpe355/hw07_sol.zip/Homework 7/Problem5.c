!! Queue of function pointers

void interrupt vDeviceA (void)
{
    !! Take care of I/O Device A
    !! Put functionA on queue of function pointers
}

void interrupt vDeviceB (void)
{
    !! Take care of I/O Device B
    !! Put functionB on queue of function pointers
}

void functionA (void)
{
    !! Handle actions required by Device A
}

void functionB (void)
{
    !! Handle actions required by Device B
}

double funtionPointer (void)
{
    !! Adds pointer to back of queue
}

double functionRead (void)
{
    !! Reads first item from the front of the queue
}

void main (void)
{
    while(TRUE)
    {
        while(!! Queue of function pointers is empty)
        {
            !! Call and read first function on front of queue
            return;
        }
        return;
    }
}
