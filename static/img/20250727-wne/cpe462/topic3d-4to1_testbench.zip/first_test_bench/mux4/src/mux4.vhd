entity mux is
	port(a,b,c,d,s0,s1 : in bit;
	z : out bit);
end entity;

architecture myarch of mux is
begin			  
	z <= 
	(a AND NOT(s0) AND NOT(s1))
	OR
	(b AND s0 AND NOT(s1)) 
	OR
	(c AND NOT(s0) AND s1)
	OR
	(d AND s0 AND s1);
end architecture ;

