entity  test_mux4 is
end;

architecture bench of test_mux4 is
  component mux
    port (a, b, c, d, s0, s1: in bit;
    z :out bit);
  end component;

  signal a, b, c, d, z, s0, s1: bit;

begin   
	s0 <= '0', '1' after 20 ns;
	s1 <= '0', '1' after 10ns, '0' after 20 ns, '1' after 30 ns;
    a <= '0', '1' after 5 ns;
    b <= '0', '1' after 20 ns, '0' after 30 ns;
    c <= '0', '1' after 10 ns, '0' after 20 ns, '1' after 25 ns;
    d <= '0', '1' after 15 ns, '1' after 25 ns;

    m: mux port map (a, b, c, d, s0, s1, z);

end bench;