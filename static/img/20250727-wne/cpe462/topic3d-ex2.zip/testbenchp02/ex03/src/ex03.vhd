library IEEE;
use IEEE.std_logic_1164.all;

entity ex03 is
    port (
        en,d3,d2,d1,d0,s1,s0: in STD_LOGIC;
         y: out STD_LOGIC
         );
end entity ex03;
		    
architecture myarch of ex03 is
begin
y<='0' when (en='0') else
    d0 when (s1='0' and s0='0') else
    d1 when (s1='0' and s0='1') else
    d2 when (s1='1' and s0='0') else
    d3;
end architecture myarch;