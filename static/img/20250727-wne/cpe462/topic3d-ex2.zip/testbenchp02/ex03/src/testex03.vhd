library IEEE;
use IEEE.std_logic_1164.all;

entity  test_ex03 is
end;

architecture testbench of test_ex03 is

component ex03
    port (en, d3, d2, d1, d0, s1, s0: in STD_LOGIC;
    y : out STD_LOGIC);
  end component;
  
signal en, d3, d2, d1, d0,s1, s0, y : STD_LOGIC;

begin	
 d0 <= '1', '0' after 20ns;
 d1 <= '1', '0' after 40ns;	
 d2 <= '1', '0' after 60ns;
 d3 <= '1', '0' after 80ns;
 en <= '0', '1' after 10ns;
 s1 <= '0', '1' after 50ns;
 s0 <= '0', '1' after 30ns, 
 '0' after 60ns,
 '1' after 80ns; 
 
 m: ex03 port map (en, d3, d2, d1, d0,s1, s0, y);

end testbench;