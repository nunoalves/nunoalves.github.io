entity adder is
    port (
        a,b,cin: in bit;
         s,cout: out bit
         );
end entity adder;

architecture arch of adder is
	signal c,d,e : bit;
begin

	c <= a XOR b;
	s <= c XOR b;
	d <= b AND cin;
	e <= a AND b;
	cout <= d OR e; 
end architecture arch;