entity  test_fa is
end;

architecture bench of test_fa is
  component adder
    port (a, b, cin: in bit;
    s,cout :out bit);
  end component;

  signal a, b, cin, s, cout: bit;

begin   
 a   <= '0', 
 '1' after 5ns, 
 '0' after 10ns, 
 '0' after 15 ns;

 b   <= '0', 
 '1' after 5ns, 
 '1' after 10ns, 
 '0' after 15 ns;

 cin <= '0', 
 '1' after 5ns, 
 '1' after 10ns, 
 '1' after 15 ns;
 
 m: adder port map (a, b, cin, s, cout);
end bench;