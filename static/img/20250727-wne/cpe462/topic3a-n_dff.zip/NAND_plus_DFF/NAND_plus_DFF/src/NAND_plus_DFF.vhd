entity example is
	port (a,b,clk : in bit;
	q: out bit);
end example;

architecture example of example is	
signal temp : bit;	
	begin
		temp <= a NAND b;
		process (clk)
			begin
			if (clk'event and clk='1') then q<=temp;
			end if;	
		end process;
	end example;
